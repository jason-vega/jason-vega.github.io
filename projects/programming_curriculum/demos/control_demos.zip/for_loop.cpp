#include <iostream>

using namespace std;

const int LETS_COUNT = 1000000;

int main() {
    for (int i = 0; i < LETS_COUNT; i++) {
        cout << i << endl;
    }

    return 0;
}

