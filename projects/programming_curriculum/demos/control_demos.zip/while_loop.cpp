#include <iostream>

using namespace std;

int main() {
    cout << "To infinity, and bey";

    while (true) {
        cout << 'o';
    }

    cout << "nd!" << endl; // Will this statement ever be executed?

    return 0;
}

